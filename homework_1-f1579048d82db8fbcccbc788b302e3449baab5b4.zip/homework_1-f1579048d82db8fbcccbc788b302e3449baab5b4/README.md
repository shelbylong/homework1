# homework_1
Code repository for Homework 1

You can use command line to fork the code or you can use the download option.

Description and Instructions at: https://docs.google.com/document/d/1lNsDFM8JuBw1dpldbnhcRoabhD7KLv0SumIbGj0mh6c/edit?usp=sharing

